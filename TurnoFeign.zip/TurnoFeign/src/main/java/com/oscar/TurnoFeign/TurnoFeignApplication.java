package com.oscar.TurnoFeign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TurnoFeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(TurnoFeignApplication.class, args);
	}

}
