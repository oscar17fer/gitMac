package com.oscar.TurnoFeign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TurnoFeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
