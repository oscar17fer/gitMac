package com.oscar.PacienteFeign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PacienteFeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(PacienteFeignApplication.class, args);
	}

}
